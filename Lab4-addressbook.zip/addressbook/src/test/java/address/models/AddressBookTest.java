package address.models;


import org.junit.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;


import java.util.ArrayList;

public class AddressBookTest {

    public static AddressBook aBook;
    public static BuddyInfo buddy1;
    public static BuddyInfo buddy2;

    @BeforeEach
    public  void init(){
        aBook = new AddressBook();
        aBook.setId(1);
        buddy1 = new BuddyInfo();
        buddy2 = new BuddyInfo();

        buddy1.setName("joe");
        buddy1.setPhoneNumber("613");
        buddy1.setAddress("address1");
        buddy1.setId(1);


        buddy2.setName("blow");
        buddy2.setPhoneNumber("614");
        buddy2.setAddress("address2");
        buddy2.setId(2);
    }

    @Test
    public void testSetBuddyList() {
        ArrayList<BuddyInfo>  list = new ArrayList<>();
        list.add(new BuddyInfo("anme", "stuff", "otherStuff"));

        aBook.setBuddyList(list);
        Assert.assertEquals(aBook.getBuddyList().get(0).getName(), list.get(0).getName());
    }
    @Test
    public void testGetBuddyList() {
        aBook.addBuddy(buddy1);
        Assert.assertEquals(aBook.getBuddyList().get(0).getName(), buddy1.getName());
    }
    @Test
    public void testGetSize(){
        aBook.addBuddy(buddy1);
        Assert.assertEquals(aBook.getSize(),1);
    }
    @Test
    public void testAddBuddy() {
        Assert.assertEquals(aBook.getSize(), 0);
        aBook.addBuddy(buddy1);
        Assert.assertEquals(aBook.getSize(), 1);
        aBook.addBuddy(buddy2);
        Assert.assertEquals(aBook.getSize(),2);
    }

    @Test
    public void testDeleteBuddy() {
        Assert.assertEquals(aBook.getSize(), 0);
        aBook.addBuddy(buddy1);
        Assert.assertEquals(aBook.getSize(), 1);
        aBook.deleteBuddy(buddy1);
        Assert.assertEquals(aBook.getSize(),0);
    }

    @Test
    public void testToStringTest(){
        Assert.assertEquals(aBook.toString(), "This addressbook has: " +"0"+ " buddies\n");
        aBook.addBuddy(buddy1);
        Assert.assertEquals(aBook.toString(), "This addressbook has: " +"1"+ " buddies\njoe address1 613\n");
    }
}