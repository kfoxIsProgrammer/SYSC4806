package address;

import address.addressbookrepointerfaces.AddressBookRepository;
import address.models.AddressBook;
import address.models.BuddyInfo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.servlet.ViewResolver;
import org.springframework.web.servlet.view.InternalResourceViewResolver;


@SpringBootApplication
public class AddressbookApplication {
	private static final Logger log = LoggerFactory.getLogger(AddressbookApplication.class);

	public static void main(String[] args) {
		SpringApplication.run(AddressbookApplication.class, args);
	}
/*
	@Bean
	public CommandLineRunner demo(AddressBookRepository repository) {
		return (args) -> {
			AddressBook aBook = new AddressBook();
			aBook.addBuddy(new BuddyInfo("Jack", "address1", "613-545-454"));
			aBook.addBuddy(new BuddyInfo("Kevin", "address2", "613-545-455"));
			aBook.addBuddy(new BuddyInfo("Craig", "address3", "613-545-456"));
			aBook.addBuddy(new BuddyInfo("Joe", "address4", "613-545-457"));
			aBook.addBuddy(new BuddyInfo("Blow", "address5", "613-545-458"));

			repository.save(aBook);
			// fetch all customers
			log.info("AddressBook found with findAll():");
			log.info("-------------------------------");
			AddressBook book = repository.findAddressBookById(1);
			log.info("Printing all Buddies found in the AddressBook:");
			for (BuddyInfo buddy : book.getBuddyList()) {
				log.info(buddy.toString());
			}
			log.info("");

		};
	}*/

}
